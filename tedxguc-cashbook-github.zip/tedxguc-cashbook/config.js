// Paste your Supabase project's values here.
// Supabase → Project Settings → API → "Project URL" and "anon public" key.
// The anon key is meant to be public: the database rules (schema.sql) decide who can read or write.
window.CASHBOOK_CONFIG = {
  supabaseUrl: "https://YOUR-PROJECT-ID.supabase.co",
  supabaseAnonKey: "YOUR-ANON-PUBLIC-KEY",
};
